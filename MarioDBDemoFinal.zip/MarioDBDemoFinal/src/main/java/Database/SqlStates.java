package Database;

import Model.Pizza;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class SqlStates {

    public void clearDB(String dataBaseName) {
        String sql = "TRUNCATE TABLE " + dataBaseName;
        try {
            Connection con = DatabaseConnector.getConnector();
            PreparedStatement ps = con.prepareStatement(sql);
            ps.execute();
        } catch (SQLException ex) {
            Logger.getLogger(SqlStates.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public ArrayList<Pizza> getPizzas(String dataBaseName) {
        ArrayList<Pizza> pizzas = new ArrayList();
        try {
            Connection con = DatabaseConnector.getConnector();
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM " + dataBaseName);
            while (rs.next()) {
                int id = rs.getInt("id");
                String name = rs.getString("name");
                String description = rs.getString("description");
                int price = rs.getInt("price");

                Pizza pizza = new Pizza(name, id, description, price);
                pizzas.add(pizza);

            }
        } catch (SQLException ex) {
            Logger.getLogger(SqlStates.class.getName()).log(Level.SEVERE, null, ex);
        }
        return pizzas;
    }

    public void InsertPizza(Pizza pizza, String dataBaseName) {
        String sql = "INSERT INTO " + dataBaseName + " (id, name, description, price) VALUES (?,?,?,?)";
        try {
            Connection con = DatabaseConnector.getConnector();
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, pizza.getPizzaNr());
            ps.setString(2, pizza.getPizzaNavn());
            ps.setString(3, pizza.getBeskrivelse());
            ps.setInt(4, pizza.getPris());
            ps.executeUpdate();

        } catch (SQLException ex) {
            Logger.getLogger(SqlStates.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
