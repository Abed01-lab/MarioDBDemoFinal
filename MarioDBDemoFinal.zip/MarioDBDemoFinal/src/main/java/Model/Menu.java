// @Abed
// @Sumit
// @ Gustav
//Hello

package Model;

import Database.SqlStates;
import java.util.ArrayList;


public class Menu {

    ArrayList <Pizza> menuListe =  new SqlStates().getPizzas("menu");
    
    public void printMenu (){
        for(Pizza pizza: menuListe)
            System.out.println(pizza);
    }
}
