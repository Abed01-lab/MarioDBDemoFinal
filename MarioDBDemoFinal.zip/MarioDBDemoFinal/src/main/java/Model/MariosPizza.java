// @Abed
// @Sumit
// @ Gustav

package Model;

import Model.Udføre;
import java.io.IOException;

public class MariosPizza {

//    public static void main(String[] args) throws IOException {
//        Udføre udføre = new Udføre();
//        JUnitCore core = new JUnitCore(Package.getPackage(Model));
//        udføre.startProgram();
//
//    }
}
