
package Model;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.Before;

public class MarioTest {

    //Tester om det der bliver tilføjede det korrekte antal
    @Test
    public void tilføjBestillingTilListe() {
        //Arrange
        BestillingsListe bestillingsListe = new BestillingsListe();
        Menu menu = new Menu();
        Omsætning omsætning = new Omsætning();

        int antal = 6;
        int nr = 2;

        //Act
        for (int i = 0; i < antal; i++) {
            bestillingsListe.tilføj(menu.menuListe.get(nr));
            omsætning.tilføj(menu.menuListe.get(nr));
        }

        //Assert
        assertEquals(antal, bestillingsListe.bestillingsListe.size());
        assertEquals(antal, omsætning.omsætningsListe.size());
    }

    //Tester om alle pizza i omsætningslisten bliver printet
    @Test
    public void eksportereOmsætningTiltxtTest() throws IOException {
        //Arrange
        Omsætning omsætning = new Omsætning();
        Menu menu = new Menu();
        File file = new File("Omsætning.text");
        BufferedWriter bw = new BufferedWriter(new FileWriter(file));
        Scanner scan = new Scanner(file);

        int antal = 10;
        int nr = 1;
        int expectedLinjes = 0;
        String str;

        //Act
        for (int i = 0; i < antal; i++) {
            omsætning.tilføj(menu.menuListe.get(nr - 1));
        }
        
         int maxCounter = 0;
        Pizza favoritePizza = new Pizza("Vesuvio", 1, "pizza med ost", 57);

        for (int i = 0; i < omsætning.omsætningsListe.size(); i++) {
            int counter = 1;
            for (int j = 0; j < omsætning.omsætningsListe.size(); j++) {
                if (omsætning.omsætningsListe.get(i) == omsætning.omsætningsListe.get(j)) {
                    counter++;
                }
            }

            if (maxCounter < counter) {
                maxCounter = counter;
                favoritePizza = (Pizza) omsætning.omsætningsListe.get(i);
            }
        }
        
        

        bw.write("Pizza: \n");
        for (Pizza pizza : omsætning.omsætningsListe) {
            bw.write(pizza.toString());
            bw.newLine();
        }
        
        bw.write("Total omsætning: " + omsætning.beregn());
        bw.write("\n");
        bw.write("\nFarvorit Pizza: " + favoritePizza.pizzaNavn);
        bw.close();
        
        while (scan.hasNextLine()) {
            str = scan.nextLine();
            expectedLinjes++;
        }
        
        //Assert
        assertEquals(expectedLinjes, omsætning.omsætningsListe.size() + 4);
    }
    
    @Test 
    public void omsætningTest(){
        Omsætning omsætning = new Omsætning();
        Menu menu = new Menu();
        
        int antal = 3;
        int nr = 1;
        int total = 171;

        //Act
        for (int i = 0; i < antal; i++) {
            omsætning.tilføj(menu.menuListe.get(nr - 1));
        }
        assertEquals(total, omsætning.beregn());
    }
    
    @Test
    public void fjernBestillingFraListe() {

        BestillingsListe bestillingsListe = new BestillingsListe();
        Menu menu = new Menu();

        int antal = 10;
        int nr = 4;

        for (int i = 0; i < antal; i++) {
            bestillingsListe.tilføj(menu.menuListe.get(nr - 1));
        
        }
            bestillingsListe.fjern(7);
            bestillingsListe.fjern(2);

        assertEquals(antal - 2, bestillingsListe.bestillingsListe.size());

    }    
    
    @Test
    public void farvoritePizza(){
        
     Omsætning omsætning = new Omsætning();
     Menu menu = new Menu();
   
        omsætning.tilføj(menu.menuListe.get(1));
        omsætning.tilføj(menu.menuListe.get(2));
        omsætning.tilføj(menu.menuListe.get(2));
     
     int maxCounter = 0;
        Pizza favoritPizza = new Pizza("", 0,"", 0);

        for (int i = 0; i < omsætning.omsætningsListe.size(); i++) {
            int counter = 0;
            for (int j = 0; j < omsætning.omsætningsListe.size(); j++) {
                if (omsætning.omsætningsListe.get(i) == omsætning.omsætningsListe.get(j)) {
                    counter++;
                }
            }

            if (maxCounter < counter) {
                maxCounter = counter;
                favoritPizza = (Pizza) omsætning.omsætningsListe.get(i);
            }
        }
     assertEquals(favoritPizza, menu.menuListe.get(2));
    }
    
    Pizza pizza = new Pizza("Vesuvio", 1, "tomatsauce, ost, skinke", 57);

    @Test
    public void navnTest() {
        String forventet = "Vesuvio";
        String resultat = pizza.getPizzaNavn();
        assertEquals(forventet, resultat);
    }
    
    @Test
    public void prisTest() {
        int forventet = 57;
        int resultat = pizza.getPris();
        assertEquals(forventet, resultat);
    }
    
    @Test
    public void beskrivelsesTest() {
        String forventet = "tomatsauce, ost, skinke";
        String resultat = pizza.getBeskrivelse();
        assertEquals(forventet, resultat);
    }
    
    @Test 
    public void notNull(){
    assertNotNull(pizza);
    }

}
