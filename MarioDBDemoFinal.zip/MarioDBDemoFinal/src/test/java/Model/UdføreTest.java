
package Model;

import java.io.IOException;

public class UdføreTest {
    MarioTest mt = new MarioTest();
    private void Tester() throws IOException{
        
        mt.tilføjBestillingTilListe();
        System.out.println("tilføjBestillingTilListe test succesfuld...");
        
        mt.eksportereOmsætningTiltxtTest();
        System.out.println("eksportereOmsætningTiltxtTest test succesfuld...");
        
        mt.omsætningTest();
        System.out.println("omsætningTest test succesfuld...");
        
        mt.fjernBestillingFraListe();
        System.out.println("fjernBestillingFraListe test succesfuld...");
        
        mt.farvoritePizza();
        System.out.println("farvoritePizza test succesfuld...");
        
        mt.navnTest();
        System.out.println("navnTest test succesfuld...");
        
        mt.prisTest();
        System.out.println("prisTest test succesfuld...");
        
        mt.beskrivelsesTest();
        System.out.println("beskrivelsesTest test succesfuld...");
        
        mt.notNull();
        System.out.println("notNull test succesfuld...");
        
    }
    
    public static void main(String[] args) throws IOException {
        new UdføreTest().Tester();
        new Udføre().startProgram();
    }
    
}
